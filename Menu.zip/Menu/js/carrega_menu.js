  $(function(){
     $("#menu").load("menu.html"); 
  });